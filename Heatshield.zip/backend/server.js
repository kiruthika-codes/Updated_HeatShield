const express = require("express");
const axios = require("axios");
const cors = require("cors");

const app = express();

app.use(cors());

const PORT = 5000;


// =====================================================
// HOME
// =====================================================

app.get("/", (req, res) => {

    res.json({
        message: "HeatShield backend is running!"
    });

});


// =====================================================
// TEST
// =====================================================

app.get("/api/test", (req, res) => {

    res.json({
        success: true,
        message: "HeatShield API is working!"
    });

});


// =====================================================
// WEATHER API
// =====================================================

app.get("/api/weather", async (req, res) => {

    try {

        const { lat, lon } = req.query;


        if (!lat || !lon) {

            return res.status(400).json({
                error: "Latitude and longitude are required"
            });

        }


        const response = await axios.get(
            "https://api.open-meteo.com/v1/forecast",
            {

                params: {

                    latitude: lat,

                    longitude: lon,

                    current:
                        "temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,uv_index"

                }

            }
        );


        const current =
            response.data.current;


        console.log(
            "Weather data:",
            current
        );


        res.json({

            location: {

                latitude: Number(lat),

                longitude: Number(lon)

            },

            temperature:
                current.temperature_2m,

            humidity:
                current.relative_humidity_2m,

            feelsLike:
                current.apparent_temperature,

            windSpeed:
                current.wind_speed_10m,

            // Keep the original API field too
            wind_speed_10m:
                current.wind_speed_10m,

            uvIndex:
                current.uv_index

        });

    }

    catch (error) {

        console.error(
            "Weather API error:",
            error.message
        );


        res.status(500).json({

            error:
                "Unable to fetch weather data"

        });

    }

});


// =====================================================
// RISK API
// =====================================================

app.get("/api/risk", async (req, res) => {

    try {

        const { lat, lon } = req.query;


        if (!lat || !lon) {

            return res.status(400).json({

                error:
                    "Latitude and longitude are required"

            });

        }


        const response = await axios.get(
            "https://api.open-meteo.com/v1/forecast",
            {

                params: {

                    latitude: lat,

                    longitude: lon,

                    current:
                        "temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,uv_index"

                }

            }
        );


        const current =
            response.data.current;


        const temperature =
            current.temperature_2m;

        const humidity =
            current.relative_humidity_2m;

        const feelsLike =
            current.apparent_temperature;

        const windSpeed =
            current.wind_speed_10m;

        const uvIndex =
            current.uv_index;


        // =================================================
        // RISK CALCULATION
        // =================================================

        let riskLevel;


        if (feelsLike >= 45) {

            riskLevel = "EXTREME";

        }

        else if (feelsLike >= 40) {

            riskLevel = "HIGH";

        }

        else if (feelsLike >= 35) {

            riskLevel = "MODERATE";

        }

        else {

            riskLevel = "LOW";

        }


        console.log(
            "Risk data:",
            {
                temperature,
                humidity,
                feelsLike,
                windSpeed,
                uvIndex,
                riskLevel
            }
        );


        res.json({

            location: {

                latitude:
                    Number(lat),

                longitude:
                    Number(lon)

            },

            temperature,

            humidity,

            feelsLike,

            windSpeed,

            // Also send original Open-Meteo name
            wind_speed_10m:
                windSpeed,

            uvIndex,

            riskLevel

        });

    }

    catch (error) {

        console.error(
            "Risk API error:",
            error.message
        );


        res.status(500).json({

            error:
                "Unable to calculate heat risk"

        });

    }

});


// =====================================================
// LOCATION API
// =====================================================

app.get("/api/location", async (req, res) => {

    try {

        const { lat, lon } = req.query;


        if (!lat || !lon) {

            return res.status(400).json({

                error:
                    "Latitude and longitude are required"

            });

        }


        const response = await axios.get(
            "https://nominatim.openstreetmap.org/reverse",
            {

                params: {

                    lat: lat,

                    lon: lon,

                    format: "json",

                    zoom: 10,

                    addressdetails: 1

                },

                headers: {

                    "User-Agent":
                        "HeatShield/1.0"

                }

            }
        );


        const address =
            response.data.address || {};


        const city =
            address.city ||
            address.town ||
            address.municipality ||
            address.county ||
            address.village ||
            "Unknown location";


        const state =
            address.state ||
            "";


        const locationName =
            state
                ? `${city}, ${state}`
                : city;


        console.log(
            "Reverse location:",
            {
                latitude: lat,
                longitude: lon,
                locationName
            }
        );


        res.json({

            city,

            state,

            locationName

        });

    }

    catch (error) {

        console.error(
            "Location API error:",
            error.message
        );


        res.status(500).json({

            error:
                "Unable to find location"

        });

    }

});

// =========================
// SEARCH LOCATION
// =========================

app.get("/api/search-location", async (req, res) => {
    try {
        const { city } = req.query;

        if (!city) {
            return res.status(400).json({
                error: "City or district is required"
            });
        }

        const response = await axios.get(
            "https://geocoding-api.open-meteo.com/v1/search",
            {
                params: {
                    name: city,
                    count: 5,
                    language: "en",
                    format: "json"
                }
            }
        );

        if (
            !response.data.results ||
            response.data.results.length === 0
        ) {
            return res.status(404).json({
                error: "Location not found"
            });
        }

        const results = response.data.results.map(place => ({
            name: place.name,
            state: place.admin1 || "",
            country: place.country || "",
            latitude: place.latitude,
            longitude: place.longitude
        }));

        res.json({
            results: results
        });

    } catch (error) {

        console.error(
            "Location search error:",
            error.message
        );

        res.status(500).json({
            error: "Unable to search location"
        });
    }
});

// =====================================================
// START SERVER
// =====================================================

app.listen(
    PORT,
    () => {

        console.log(
            `HeatShield backend running at http://localhost:${PORT}`
        );

    }
);