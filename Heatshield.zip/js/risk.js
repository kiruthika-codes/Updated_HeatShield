// =====================================================
// HEATSHIELD - HEAT RISK PAGE
// =====================================================

// Current heat data
let heatData = null;


// =====================================================
// HELPER - SAFELY UPDATE HTML ELEMENT
// =====================================================

function setText(id, value) {

    const element = document.getElementById(id);

    if (element) {
        element.textContent = value;
    }

}


// =====================================================
// RISK MESSAGE
// =====================================================

function getRiskMessage(riskLevel) {

    switch (riskLevel) {

        case "EXTREME":
            return "Extreme heat conditions are present. Avoid prolonged outdoor exposure and take immediate precautions.";

        case "HIGH":
            return "High heat conditions are present. Extra precautions are recommended.";

        case "MODERATE":
            return "Moderate heat conditions are present. Stay hydrated and take regular breaks.";

        case "LOW":
        default:
            return "Heat conditions are currently low. Continue normal heat-safety precautions.";
    }

}


// =====================================================
// UPDATE RISK SLIDER
// =====================================================

function updateRiskSlider(riskLevel) {

    // Try different possible slider IDs
    const slider =
        document.getElementById("riskSlider") ||
        document.getElementById("heatSlider");

    if (!slider) {
        return;
    }

    const positions = {

        LOW: 25,

        MODERATE: 50,

        HIGH: 75,

        EXTREME: 95

    };

    slider.style.setProperty(
        "--risk-position",
        `${positions[riskLevel] || 25}%`
    );

}


// =====================================================
// LOAD WEATHER + RISK DATA
// =====================================================

async function loadHeatData(
    latitude,
    longitude,
    locationName = null
) {

    try {

        console.log(
            "Loading weather for:",
            latitude,
            longitude
        );


        // -------------------------------------------------
        // REQUEST RISK DATA
        // -------------------------------------------------

        const response = await fetch(
            `http://localhost:5000/api/risk?lat=${latitude}&lon=${longitude}`
        );


        if (!response.ok) {

            throw new Error(
                "Backend risk API failed"
            );

        }


        const data =
            await response.json();


        console.log(
            "Risk API response:",
            data
        );


        // -------------------------------------------------
        // CREATE HEAT DATA
        // -------------------------------------------------

        const windSpeed =
    data.windSpeed ?? data.wind_speed_10m ?? 0;

heatData = {
    location: locationName,
    temperature: data.temperature,
    humidity: data.humidity,
    uv: data.uvIndex,
    wind: windSpeed,
    feelsLike: data.feelsLike,
    heatIndex: data.feelsLike,
    risk: `${data.riskLevel} HEAT RISK`,
    message: getRiskMessage(data.riskLevel)
};




        // -------------------------------------------------
        // UPDATE LOCATION
        // -------------------------------------------------

        setText(
            "locationName",
            heatData.location
        );


        // -------------------------------------------------
        // UPDATE TEMPERATURE
        // -------------------------------------------------

        setText(
            "temperature",
            heatData.temperature
        );


        // -------------------------------------------------
        // UPDATE HUMIDITY
        // -------------------------------------------------

        setText(
            "humidity",
            heatData.humidity
        );


        // -------------------------------------------------
        // UPDATE UV INDEX
        // -------------------------------------------------

        setText(
            "uvIndex",
            heatData.uv
        );


        // -------------------------------------------------
        // UPDATE WIND SPEED
        // -------------------------------------------------

        // Supports either ID
        setText(
    "wind",
    Number(heatData.wind).toFixed(1)
);

setText(
    "windSpeed",
    Number(heatData.wind).toFixed(1)
);


        // -------------------------------------------------
        // UPDATE FEELS LIKE
        // -------------------------------------------------

        setText(
            "feelsLike",
            `${heatData.feelsLike}°C`
        );


        // -------------------------------------------------
        // UPDATE HEAT INDEX
        // -------------------------------------------------

        setText(
            "heatIndex",
            heatData.heatIndex
        );


        // -------------------------------------------------
        // UPDATE RISK LEVEL
        // -------------------------------------------------

        setText(
            "riskLevel",
            heatData.risk
        );


        // -------------------------------------------------
        // UPDATE RISK MESSAGE
        // -------------------------------------------------

        setText(
            "riskMessage",
            heatData.message
        );


        // -------------------------------------------------
        // UPDATE SLIDER
        // -------------------------------------------------

        updateRiskSlider(
            data.riskLevel
        );

        // -------------------------------------------------
        // UPDATE TIME
        // -------------------------------------------------

        updateTime();


        console.log(
            "HeatShield page updated successfully."
        );

    }

    catch (error) {

        console.error(
            "HeatShield weather error:",
            error
        );


        setText(
            "riskMessage",
            "Unable to load current heat information."
        );

    }

}


// =====================================================
// GET LOCATION NAME
// =====================================================

async function getLocationName(
    latitude,
    longitude
) {

    try {

        console.log(
            "Finding location name..."
        );


        const response = await fetch(
            `http://localhost:5000/api/location?lat=${latitude}&lon=${longitude}`
        );


        if (!response.ok) {

            throw new Error(
                "Location API failed"
            );

        }


        const data =
            await response.json();


        console.log(
            "Location API response:",
            data
        );


        if (
            data.locationName &&
            data.locationName.trim() !== ""
        ) {

            return data.locationName;

        }


        return null;

    }

    catch (error) {

        console.error(
            "Location name error:",
            error
        );


        return null;

    }

}


// =====================================================
// GET CURRENT GPS LOCATION
// =====================================================

function detectCurrentLocation() {

    return new Promise(
        (resolve, reject) => {

            if (!navigator.geolocation) {

                reject(
                    new Error(
                        "Geolocation is not supported by this browser."
                    )
                );

                return;

            }


            navigator.geolocation.getCurrentPosition(

                position => {

                    const latitude =
                        position.coords.latitude;

                    const longitude =
                        position.coords.longitude;


                    console.log(
                        "GPS Latitude:",
                        latitude
                    );

                    console.log(
                        "GPS Longitude:",
                        longitude
                    );


                    resolve({

                        latitude,
                        longitude

                    });

                },


                error => {

                    console.error(
                        "GPS Error:",
                        error
                    );


                    reject(error);

                },


                {

                    enableHighAccuracy: true,

                    timeout: 15000,

                    maximumAge: 0

                }

            );

        }
    );

}


// =====================================================
// LOCATION BUTTON
// =====================================================

const locationButton =
    document.getElementById(
        "locationButton"
    );

const locationText =
    document.getElementById(
        "locationText"
    );


if (locationButton) {

    locationButton.addEventListener(
        "click",
        async () => {

            try {

                // -----------------------------------------
                // BUTTON STATUS
                // -----------------------------------------

                if (locationText) {

                    locationText.textContent =
                        "Detecting location...";

                }


                locationButton.disabled =
                    true;


                // -----------------------------------------
                // GET GPS
                // -----------------------------------------

                const locationData =
                    await detectCurrentLocation();


                const latitude =
                    locationData.latitude;

                const longitude =
                    locationData.longitude;


                // -----------------------------------------
                // SAVE GPS
                // -----------------------------------------

                localStorage.setItem(
                    "heatShieldLocation",
                    JSON.stringify({

                        latitude,
                        longitude

                    })
                );


                // -----------------------------------------
                // SHOW STATUS
                // -----------------------------------------

                if (locationText) {

                    locationText.textContent =
                        "Location detected";

                }


                // -----------------------------------------
                // FIRST LOAD WEATHER
                // -----------------------------------------

                await loadHeatData(
                    latitude,
                    longitude,
                    "Finding location..."
                );


                // -----------------------------------------
                // FIND CITY / STATE
                // -----------------------------------------

                const locationName =
                    await getLocationName(
                        latitude,
                        longitude
                    );


                // -----------------------------------------
                // UPDATE WITH REAL CITY NAME
                // -----------------------------------------

                if (locationName) {

                    setText(
                        "locationName",
                        locationName
                    );


                    // Update stored location with name
                    localStorage.setItem(
                        "heatShieldLocation",
                        JSON.stringify({

                            latitude,
                            longitude,
                            locationName

                        })
                    );


                    console.log(
                        "Final location:",
                        locationName
                    );

                }

                else {

                    console.log(
                        "Could not find city name."
                    );

                }


            }

            catch (error) {

                console.error(
                    "Location detection error:",
                    error
                );


                if (locationText) {

                    if (
                        error.code === 1
                    ) {

                        locationText.textContent =
                            "Location permission denied";

                    }

                    else if (
                        error.code === 2
                    ) {

                        locationText.textContent =
                            "Location unavailable";

                    }

                    else if (
                        error.code === 3
                    ) {

                        locationText.textContent =
                            "Location request timed out";

                    }

                    else {

                        locationText.textContent =
                            "Unable to detect location";

                    }

                }

            }

            finally {

                locationButton.disabled =
                    false;

            }

        }
    );

}


// =====================================================
// LOAD SAVED LOCATION
// =====================================================

async function loadSavedLocation() {

    const savedLocation =
        localStorage.getItem(
            "heatShieldLocation"
        );


    // No saved location
    if (!savedLocation) {

        console.log(
            "No saved location found."
        );

        return;

    }


    try {

        const locationData =
            JSON.parse(
                savedLocation
            );


        const latitude =
            locationData.latitude;

        const longitude =
            locationData.longitude;


        if (
            typeof latitude !== "number" ||
            typeof longitude !== "number"
        ) {

            throw new Error(
                "Invalid saved coordinates"
            );

        }


        console.log(
            "Loading saved GPS:",
            latitude,
            longitude
        );


        if (locationText) {

            locationText.textContent =
                "Loading saved location...";

        }


        // If we already saved the location name,
        // use it immediately.
        if (
            locationData.locationName
        ) {

            setText(
                "locationName",
                locationData.locationName
            );

        }


        // Load weather
        await loadHeatData(
            latitude,
            longitude,
            locationData.locationName ||
            "Location detected"
        );


        // Get fresh city name
        const locationName =
            await getLocationName(
                latitude,
                longitude
            );


        if (locationName) {

            setText(
                "locationName",
                locationName
            );


            // Save fresh location name
            localStorage.setItem(
                "heatShieldLocation",
                JSON.stringify({

                    latitude,
                    longitude,
                    locationName

                })
            );

        }


        if (locationText) {

            locationText.textContent =
                "Location detected";

        }

    }

    catch (error) {

        console.error(
            "Invalid saved location:",
            error
        );


        localStorage.removeItem(
            "heatShieldLocation"
        );

    }

}


// =====================================================
// MOBILE MENU
// =====================================================

const menuButton =
    document.getElementById(
        "menuButton"
    );

const navLinks =
    document.getElementById(
        "navLinks"
    );


if (
    menuButton &&
    navLinks
) {

    menuButton.addEventListener(
        "click",
        () => {

            navLinks.classList.toggle(
                "open"
            );

        }
    );

}


// =====================================================
// SAFETY MODAL
// =====================================================

const modal =
    document.getElementById(
        "infoModal"
    );

const modalTitle =
    document.getElementById(
        "modalTitle"
    );

const modalText =
    document.getElementById(
        "modalText"
    );


const learnButtons =
    document.querySelectorAll(
        ".learn-button"
    );


if (modal) {

    learnButtons.forEach(
        button => {

            button.addEventListener(
                "click",
                () => {

                    if (modalTitle) {

                        modalTitle.textContent =
                            button.dataset.title || "";

                    }


                    if (modalText) {

                        modalText.textContent =
                            button.dataset.text || "";

                    }


                    modal.classList.add(
                        "show"
                    );

                }
            );

        }
    );

}


// =====================================================
// CLOSE MODAL
// =====================================================

function closeModal() {

    if (modal) {

        modal.classList.remove(
            "show"
        );

    }

}


const modalClose =
    document.getElementById(
        "modalClose"
    );

const modalDone =
    document.getElementById(
        "modalDone"
    );


if (modalClose) {

    modalClose.addEventListener(
        "click",
        closeModal
    );

}


if (modalDone) {

    modalDone.addEventListener(
        "click",
        closeModal
    );

}


if (modal) {

    modal.addEventListener(
        "click",
        event => {

            if (
                event.target === modal
            ) {

                closeModal();

            }

        }
    );

}


// =====================================================
// ESC KEY
// =====================================================

document.addEventListener(
    "keydown",
    event => {

        if (
            event.key === "Escape"
        ) {

            closeModal();

        }

    }
);


// =====================================================
// EMERGENCY BUTTON
// =====================================================

const emergencyButton =
    document.getElementById(
        "emergencyButton"
    );


if (emergencyButton) {

    emergencyButton.addEventListener(
        "click",
        () => {

            window.location.href =
                "emergency.html";

        }
    );

}


// =====================================================
// UPDATE TIME
// =====================================================

function updateTime() {

    const now =
        new Date();


    const time =
        now.toLocaleTimeString(
            [],
            {

                hour: "2-digit",

                minute: "2-digit"

            }
        );


    setText(
        "updatedTime",
        `Updated ${time}`
    );

}

// =====================================================
// LOCATION SEARCH
// =====================================================

const locationSearch =
    document.getElementById("locationSearch");

const searchLocationButton =
    document.getElementById("searchLocationButton");

const searchResult =
    document.getElementById("searchResult");


// Search button

searchLocationButton.addEventListener("click", async () => {

    const searchText =
        locationSearch.value.trim();

    if (!searchText) {

        searchResult.textContent =
            "Please enter a city or district.";

        return;
    }


    searchResult.textContent =
        "Searching...";


    try {

        const response = await fetch(
            `http://localhost:5000/api/search-location?city=${encodeURIComponent(searchText)}`
        );


        if (!response.ok) {

            throw new Error(
                "Location not found"
            );

        }


        const data =
            await response.json();


        if (
            !data.results ||
            data.results.length === 0
        ) {

            searchResult.textContent =
                "Location not found.";

            return;
        }


        // Clear old results

        searchResult.innerHTML = "";


        // Show search results

        data.results.forEach(place => {

            const resultItem =
                document.createElement("div");


            resultItem.className =
                "search-result-item";


            resultItem.textContent =
                `${place.name}, ${place.state}, ${place.country}`;


            // When user clicks a result

            resultItem.addEventListener(
                "click",
                () => {

                    selectLocation(place);

                }
            );


            searchResult.appendChild(
                resultItem
            );

        });

    }

    catch (error) {

        console.error(
            "Location search error:",
            error
        );


        searchResult.textContent =
            "Unable to search location.";

    }

});


// =====================================================
// SELECT SEARCHED LOCATION
// =====================================================

async function selectLocation(place) {

    console.log(
        "Selected location:",
        place.name
    );


    const latitude =
        place.latitude;

    const longitude =
        place.longitude;


    const locationName =
        `${place.name}, ${place.state}`;


    // Save selected location

    const locationData = {

        latitude:
            latitude,

        longitude:
            longitude,

        locationName:
            locationName

    };


    localStorage.setItem(
        "heatShieldLocation",
        JSON.stringify(locationData)
    );


    // Update search box

    locationSearch.value =
        place.name;


    // Update location status

    locationText.textContent =
        "Location selected";


    // Update location heading immediately

    document.getElementById(
        "locationName"
    ).textContent =
        locationName;


    // Hide search results

    searchResult.innerHTML = "";


    // Load weather + risk

    await loadHeatData(
        latitude,
        longitude,
        locationName
    );

}

// =====================================================
// INITIALIZE
// =====================================================

updateTime();

loadSavedLocation();